<template>
  <div>
    page2
  </div>
</template>

<script>
export default {}
</script>

<style lang="scss" scoped></style>
