<template>
  <div class="all">
    <div class="myorder">
      <span class="strong">我的订单</span>
    </div>
    <div class="dingdan">
      <div class="item"><span class="allorder">全部订单</span></div>
      <div class="item">待付款</div>
      <div class="item">待使用</div>
      <div class="item">待评价</div>
      <div class="item">退款/售后</div>
    </div>
    <div class="item">
      <ul class="list">
        <li class="item-box">
          <div class="item-img">
            <img src="./images/kaochiyijue.jpg" alt="烤翅一绝" />
          </div>
          <div class="item-des">
            <div class="title">
              <span class="strong">烤翅一绝（广财三水校区）</span>
              <span class="done">已完成</span>
            </div>
            <div class="time">下单时间：2017-09-09 12:12</div>
            <div class="price">总价: ￥43.5</div>
          </div>
          <div class="btn"><button class="button">再来一单</button></div>
        </li>
        <li class="item-box">
          <div class="item-img">
            <img src="./images/lanzhou.jpg" alt="兰州拉面" />
          </div>
          <div class="item-des">
            <div class="title">
              <span class="strong">兰州拉面</span>
              <span class="done">已完成</span>
            </div>
            <div class="time">下单时间：2018-01-09 11:12</div>
            <div class="price">总价: ￥14.5</div>
          </div>
          <div class="btn"><button class="button">再来一单</button></div>
        </li>
        <li class="item-box">
          <div class="item-img">
            <img src="./images/mutongfan.jpg" alt="木桶饭" />
          </div>
          <div class="item-des">
            <div class="title">
              <span class="strong">木桶饭（广财三水校区）</span>
              <span class="done">已完成</span>
            </div>
            <div class="time">下单时间：2018-03-09 17:12</div>
            <div class="price">总价: ￥13.5</div>
          </div>
          <div class="btn"><button class="button">再来一单</button></div>
        </li>
        <li class="item-box">
          <div class="item-img">
            <img src="./images/pitoushi.jpg" alt="披头士" />
          </div>
          <div class="item-des">
            <div class="title">
              <span class="strong">披头士（一饭）</span>
              <span class="done">已完成</span>
            </div>
            <div class="time">下单时间：2018-05-08 11:50</div>
            <div class="price">总价: ￥23.5</div>
          </div>
          <div class="btn"><button class="button">再来一单</button></div>
        </li>
        <li class="item-box">
          <div class="item-img">
            <img src="./images/zhengxin.jpg" alt="正新鸡排" />
          </div>
          <div class="item-des">
            <div class="title">
              <span class="strong">正新鸡排</span>
              <span class="done">已完成</span>
            </div>
            <div class="time">下单时间：2018-06-19 22:12</div>
            <div class="price">总价: ￥20</div>
          </div>
          <div class="btn"><button class="button">再来一单</button></div>
        </li>
        <li class="item-box">
          <div class="item-img">
            <img src="./images/yinliao1.jpg" alt="饮料" />
          </div>
          <div class="item-des">
            <div class="title">
              <span class="strong">水果总动员</span>
              <span class="done">已完成</span>
            </div>
            <div class="time">下单时间：2018-06-29 21:12</div>
            <div class="price">总价: ￥20</div>
          </div>
          <div class="btn"><button class="button">再来一单</button></div>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
export default {}
</script>

<style lang="scss" scoped>
@import '~@/assets/scss/order';
</style>
