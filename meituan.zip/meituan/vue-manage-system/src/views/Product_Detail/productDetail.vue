<template>
  <body>
    <div class="detail">
      <div class="boxItem">
        <div class="item-name">2人牛腩牛杂煲套餐</div>
        <div class="item-title">
          <div class="title-left">随时退|免预约|过期自动退</div>
          <div class="title-right">半年销量 4.6万+</div>
        </div>
        <div class="item-img">
          <img src="./images/food.jpg" alt="预览图" />
        </div>
      </div>
    </div>
    <div class="des">
      <ul class="food">
        <li>
          <div class="header">牛杂煲</div>
          <div class="detail">
            <span class="left">小灶牛腩牛杂煲（小煲）</span>
            <span class="price">￥128</span>
          </div>
        </li>
        <li>
          <div class="header">配菜拼盘</div>
          <div class="detail">
            <span class="left">开心农场（菌类蔬菜豆制品）</span>
            <span class="price">￥20</span>
          </div>
        </li>
        <li>
          <div class="header">饮品</div>
          <div class="detail">
            <span class="left">柠檬可乐（2份）</span>
            <span class="price">￥16</span>
          </div>
        </li>
        <li>
          <div class="header">备注</div>
          <div class="detail">
            <span class="left">使用时间： 11：00至次日1：00</span>
          </div>
        </li>
      </ul>
    </div>
    <div class="bottom">
      <div class="price">
        <div class="pricetop">138</div>
        <div class="sellprice">最高门市价￥174</div>
      </div>
      <button class="buy">立即抢购</button>
    </div>
    <div class="usercomment">用户评价:</div>
    <div class="comment">
      <ul>
        <li class="fenlan">
          <div class="touxiang"><img src="./images/wander.jpg" alt="头像" /></div>
          <div class="msg">
            <div class="name">Wander</div>
            <div class="logo">☆☆☆☆☆ 2020-6-12</div>
          </div>
          <p class="content">简直就非常实惠好吃，两人吃得超级爽</p>
        </li>
        <li class="fenlan">
          <div class="touxiang"><img src="./images/wander.jpg" alt="头像" /></div>
          <div class="msg">
            <div class="name">Wander</div>
            <div class="logo">☆☆☆☆☆ 2020-6-12</div>
          </div>
          <p class="content">简直就非常实惠好吃，两人吃得超级爽</p>
        </li>
        <li class="fenlan">
          <div class="touxiang"><img src="./images/wander.jpg" alt="头像" /></div>
          <div class="msg">
            <div class="name">Wander</div>
            <div class="logo">☆☆☆☆☆ 2020-6-12</div>
          </div>
          <p class="content">简直就非常实惠好吃，两人吃得超级爽</p>
        </li>
        <li class="fenlan">
          <div class="touxiang"><img src="./images/wander.jpg" alt="头像" /></div>
          <div class="msg">
            <div class="name">Wander</div>
            <div class="logo">☆☆☆☆☆ 2020-6-12</div>
          </div>
          <p class="content">简直就非常实惠好吃，两人吃得超级爽</p>
        </li>
      </ul>
    </div>
  </body>
</template>

<script>
export default {}
</script>

<style lang="scss" scoped>
@import '~@/assets/scss/detail';
</style>
