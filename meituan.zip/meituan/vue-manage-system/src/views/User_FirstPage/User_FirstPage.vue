<template>
  <body>
    <!-- 顶部搜索栏 -->
    <header>
      <div class="navbar">
        <div class="navbar-left">
          <span class="nav-city">广州<i class="icon-downarrow"></i></span>
        </div>
        <div class="nav-search">
          <input type="text" placeholder="请输入商品名或者商圈" />
        </div>
      </div>
    </header>
    <main>
      <div class="banner"><img src="./images/download_banner.png" alt="广告图" /></div>
      <!-- 导航栏 -->
      <nav class="navlist">
        <ul>
          <li class="nav-item" v-for="item in itemData" :key="item.name">
            <a href="#" class="new-href">
              <i class="nav-icon" :class="`el-icon-${item.icon}`" :style="{ background: item.color }"></i>
              <span class="nav-des">{{ item.name }}</span></a
            >
          </li>
        </ul>
      </nav>
      <!-- 附近拼团 -->
      <div class="boxWrapper">
        <h4 class="tittle">附近拼团</h4>
        <div class="box-list">
          <div class="box-item">
            <img src="./images/food.jpg" alt="美食团" />
            <div class="item-tittle">牛小灶牛腩牛杂煲</div>
            <div class="price">
              <span class="strong">￥129</span>
              <span class="line-price">￥158</span>
            </div>
          </div>
          <div class="box-item">
            <img src="./images/ktv.jpg" alt="娱乐团" />
            <div class="item-tittle">KTV欢唱4小时 免费自助餐</div>
            <div class="price">
              <span class="strong">￥75</span>
              <span class="line-price">￥158</span>
            </div>
          </div>
        </div>
      </div>
      <!-- 猜你喜欢 -->
      <div class="guessLike">
        <div class="title">-猜你喜欢-</div>
        <ul class="list">
          <li class="guessItem">
            <a href="#" class="item-href" @click="gotoLink">
              <div class="item-box">
                <div class="item-img">
                  <img src="./images/food.jpg" alt="预览图" />
                </div>
                <div class="item-des">
                  <div class="item-name">牛大灶牛腩牛杂煲</div>
                  <div class="item-title">[5点通用12人用餐，提供免费WiFi]</div>
                  <div class="price">
                    <span class="strong">129</span>
                    <span class="retailprice">门市价:￥158</span>
                    <span class="sellNum">已售4000</span>
                  </div>
                </div>
              </div></a
            >
          </li>
          <li class="guessItem">
            <a href="#" class="item-href" @click="gotoLink"
              ><div class="item-box">
                <div class="item-img">
                  <img src="./images/food.jpg" alt="预览图" />
                </div>
                <div class="item-des">
                  <div class="item-name">牛大灶牛腩牛杂煲</div>
                  <div class="item-title">[5点通用12人用餐，提供免费WiFi]</div>
                  <div class="price">
                    <span class="strong">129</span>
                    <span class="retailprice">门市价:￥158</span>
                    <span class="sellNum">已售4000</span>
                  </div>
                </div>
              </div></a
            >
          </li>
          <li class="guessItem">
            <a href="#" class="item-href" @click="gotoLink"
              ><div class="item-box">
                <div class="item-img">
                  <img src="./images/food.jpg" alt="预览图" />
                </div>
                <div class="item-des">
                  <div class="item-name">牛大灶牛腩牛杂煲</div>
                  <div class="item-title">[5点通用12人用餐，提供免费WiFi]</div>
                  <div class="price">
                    <span class="strong">129</span>
                    <span class="retailprice">门市价:￥158</span>
                    <span class="sellNum">已售4000</span>
                  </div>
                </div>
              </div></a
            >
          </li>
          <li class="guessItem">
            <a href="#" class="item-href" @click="gotoLink"
              ><div class="item-box">
                <div class="item-img">
                  <img src="./images/food.jpg" alt="预览图" />
                </div>
                <div class="item-des">
                  <div class="item-name">牛大灶牛腩牛杂煲</div>
                  <div class="item-title">[5点通用12人用餐，提供免费WiFi]</div>
                  <div class="price">
                    <span class="strong">129</span>
                    <span class="retailprice">门市价:￥158</span>
                    <span class="sellNum">已售4000</span>
                  </div>
                </div>
              </div></a
            >
          </li>
          <li class="guessItem">
            <a href="#" class="item-href" @click="gotoLink"
              ><div class="item-box">
                <div class="item-img">
                  <img src="./images/food.jpg" alt="预览图" />
                </div>
                <div class="item-des">
                  <div class="item-name">牛大灶牛腩牛杂煲</div>
                  <div class="item-title">[5点通用12人用餐，提供免费WiFi]</div>
                  <div class="price">
                    <span class="strong">129</span>
                    <span class="retailprice">门市价:￥158</span>
                    <span class="sellNum">已售4000</span>
                  </div>
                </div>
              </div></a
            >
          </li>
        </ul>
      </div>
    </main>
  </body>
</template>

<script>
export default {
  data() {
    return {
      itemData: [
        {
          name: '美食',
          icon: 'fork-spoon',
          color: '#fd9d21'
        },
        {
          name: '电影',
          icon: 'video-camera-solid',
          color: '#ff6767'
        },
        {
          name: '酒店',
          icon: 'office-building',
          color: '#8a90fa'
        },
        {
          name: '休闲娱乐',
          icon: 'cold-drink',
          color: '#fed030'
        },
        {
          name: '外卖',
          icon: 'bicycle',
          color: '#fd9d21'
        },
        {
          name: 'KTV',
          icon: 'lollipop',
          color: '#fed030'
        },
        {
          name: '周边游',
          icon: 'sunset',
          color: '#4dc6ee'
        },
        {
          name: '丽人',
          icon: 's-check',
          color: '#ff80c2'
        },
        {
          name: '小吃快餐',
          icon: 'potato-strips',
          color: '#fd9d21'
        },
        {
          name: '全部分类',
          icon: 'more',
          color: '#00d3be'
        }
      ]
    }
  },
  methods: {
    gotoLink() {
      this.$router.push({ name: 'productdetail' })
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~@/assets/scss/userfirstpage';
</style>
