<template>
  <div class="common-table">
    <el-dialog title="更新信息" :visible.sync="isShow">
      <!-- 渲染对话框，获取所在行的内容 -->
      <el-form :model="operateForm" label-width="100px">
        <el-form-item v-for="item in operateFormLabel" :key="item.label" :label="item.label">
          <el-input v-model="operateForm[item.model]" auto-complete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="isShow = false">取 消</el-button>
        <el-button type="primary" @click="confirm">确 定</el-button>
      </div>
    </el-dialog>
    <!-- 表格内容 -->
    <el-table :data="tableData" style="width: 100%;" height="500" v-loading="loading">
      <!-- 表格序号列 -->
      <el-table-column label="序号" width="85">
        <template slot-scope="scope">
          <span style="margin-left: 10px">{{ scope.$index + 1 }}</span>
        </template>
      </el-table-column>
      <!-- 表格商品图片列 -->
      <el-table-column label="商品图片" width="180">
        <template slot-scope="scope">
          <img style="width:50px;height:50px" :src="scope.row.image" alt="商品图" />
        </template>
      </el-table-column>
      <!-- 商品信息列 -->
      <el-table-column show-overflow-tooltip v-for="item in tableLabel" :key="item.name" :label="item.label">
        <template slot-scope="scope">
          <span style="margin-left: 10px">{{ scope.row[item.name] }}</span>
        </template>
      </el-table-column>
      <!-- 操作列 -->
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button size="mini" @click="handleEdit(scope.$index, scope.row)">更新信息</el-button>
          <el-button size="mini" type="danger" @click="handleDelete(scope.$index, scope.row)">下架</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
export default {
  data() {
    return {
      isShow: false,
      operateForm: {
        product: '',
        price: '',
        have: '',
        sell: ''
      },
      operateFormLabel: [
        {
          model: 'product',
          label: '产品'
        },
        {
          model: 'price',
          label: '价格'
        },

        {
          model: 'sell',
          label: '今天已卖'
        },
        {
          model: 'have',
          label: '库存'
        }
      ],
      tableData: [
        {
          image: require('./images/hanbao.jpg'),
          product: '汉堡包',
          price: 10,
          sell: 100,
          have: 140
        },
        {
          image: require('./images/jimihua.jpg'),
          product: '鸡米花',
          price: 6,
          sell: 55,
          have: 100
        },
        {
          image: require('./images/zhaji.jpg'),
          product: '炸鸡',
          price: 25,
          sell: 15,
          have: 20
        },
        {
          image: require('./images/chicken rolls.jpg'),
          product: '鸡肉卷',
          price: 25,
          sell: 15,
          have: 20
        },
        {
          image: require('./images/jitui.jpg'),
          product: '鸡腿',
          price: 6,
          sell: 50,
          have: 58
        },
        {
          image: require('./images/kaochi.jpg'),
          product: '烤翅',
          price: 8,
          sell: 50,
          have: 30
        },
        {
          image: require('./images/quanjiatong.jpg'),
          product: '全家桶',
          price: 88,
          sell: 15,
          have: 20
        },
        {
          image: require('./images/shutiao.jpg'),
          product: '薯条',
          price: 5,
          sell: 85,
          have: 30
        },
        {
          image: require('./images/tudouni.jpg'),
          product: '土豆泥',
          price: 38,
          sell: 30,
          have: 15
        },
        {
          image: require('./images/taocan.jpg'),
          product: '套餐一',
          price: 45,
          sell: 25,
          have: 20
        },
        {
          image: require('./images/taocan3.jpg'),
          product: '套餐二',
          price: 65,
          sell: 8,
          have: 20
        },
        {
          image: require('./images/taocan4.jpg'),
          product: '套餐三',
          price: 30,
          sell: 19,
          have: 17
        },
        {
          image: require('./images/yinliao1.jpg'),
          product: '玛奇朵',
          price: 25,
          sell: 60,
          have: 50
        },
        {
          image: require('./images/yinliao2.jpg'),
          product: '橙汁',
          price: 12,
          sell: 60,
          have: 40
        },
        {
          image: require('./images/yinliao3.jpg'),
          product: '冰镇可乐',
          price: 10,
          sell: 88,
          have: 99
        },
        {
          image: require('./images/xuegao1.jpg'),
          product: '雪糕',
          price: 30,
          sell: 15,
          have: 20
        },
        {
          image: require('./images/xuegao2.jpg'),
          product: '雪糕二',
          price: 25,
          sell: 60,
          have: 20
        }
      ],
      tableLabel: [
        {
          name: 'product',
          label: '商品'
        },
        {
          name: 'price',
          label: '价格 ￥'
        },
        {
          name: 'sell',
          label: '今天已售'
        },
        {
          name: 'have',
          label: '库存'
        }
      ]
    }
  },
  methods: {
    // 修改信息的方法
    handleEdit(index, row) {
      this.isShow = true
      //把当前表单数据填到表单中
      this.operateForm = row
      console.log(index, row)
    },
    //下架实现方法
    handleDelete(index, row) {
      //借助element工具确认消息
      this.$confirm('确定下架该商品嘛, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          //利用数组增删改查的splice方法实现删除一行
          this.tableData.splice(index, 1)
        })
        .then(() => {
          this.$message({
            type: 'success',
            message: '删除成功!'
          })
          //this.getList()
        })
      console.log(index, row)
    },
    //确定提交修改信息
    confirm() {
      this.isShow = false
    }
  }
}
</script>

<style lang="scss" scoped></style>
