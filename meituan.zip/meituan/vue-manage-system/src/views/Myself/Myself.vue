<template>
  <div class="myself">
    <div class="myorder">
      <span class="strong">我的</span>
    </div>
    <div class="header">
      <div class="img">
        <img src="./images/wander.jpg" alt="头像" />
      </div>
      <div class="des">
        <div class="user">taD8888888</div>
        <button class="btn">账号管理 ></button>
      </div>
    </div>
    <div class="myservice">
      <div class="content">
        <div class="strong">我的服务</div>
        <ul>
          <li class="item" v-for="item in itemData" :key="item.name">
            <i class="icon" :class="`el-icon-${item.icon}`"></i>
            <span class="des">{{ item.name }}</span>
          </li>
        </ul>
      </div>
    </div>
    <div class="myservice">
      <div class="content">
        <div class="strong">其他服务</div>
        <ul>
          <li class="item" v-for="item in itemData2" :key="item.name">
            <i class="icon" :class="`el-icon-${item.icon}`"></i>
            <span class="des">{{ item.name }}</span>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      itemData: [
        {
          name: '订单',
          icon: 's-order'
        },
        {
          name: '收藏',
          icon: 'star-on'
        },
        {
          name: '券包',
          icon: 's-claim'
        },
        {
          name: '会员卡',
          icon: 'wallet'
        }
      ],
      itemData2: [
        {
          name: '商家中心',
          icon: 's-home'
        },
        {
          name: '免费领券',
          icon: 's-ticket'
        },
        {
          name: '个税计算器',
          icon: 's-platform'
        },
        {
          name: '意见反馈',
          icon: 's-comment'
        },
        {
          name: '规则中心',
          icon: 'remove'
        }
      ]
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~@/assets/scss/myself';
</style>
